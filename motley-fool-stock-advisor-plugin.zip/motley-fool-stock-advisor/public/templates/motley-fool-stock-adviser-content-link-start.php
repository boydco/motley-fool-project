<?php
/**
 * The view for the content link start used in the loop
 */

?><a class="job-list-link" href="<?php echo esc_url( get_permalink( $item->ID ) ); ?>">