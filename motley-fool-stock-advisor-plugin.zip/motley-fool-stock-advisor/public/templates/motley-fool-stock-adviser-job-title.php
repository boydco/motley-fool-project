<?php
/**
 * The view for the job title used in the loop
 */

?><span class="job-list-name" itemprop="name"><?php echo $item->post_title; ?></span>