<?php
/**
 * The view for the post content used on the single post
 */

?>
<!-- <aside>this is the aside</aside> -->
