<?php
/**
 * The view for the employee list wrap start used in the loop
 */

?><div class="employee-list-wrap">