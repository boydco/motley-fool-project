<?php
/**
 * The view for the content wrap start used in the loop
 */

?><dl class="hentry">