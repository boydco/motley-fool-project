<?php
/**
 * The view for the employee list wrap end used in the loop
 */

?></div><!-- .employee-list-wrap -->