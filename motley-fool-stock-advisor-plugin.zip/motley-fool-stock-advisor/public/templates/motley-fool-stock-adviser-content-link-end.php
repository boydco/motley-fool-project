<?php
/**
 * The view for the content link end used in the loop
 */

?></a><!-- .job-list-link -->