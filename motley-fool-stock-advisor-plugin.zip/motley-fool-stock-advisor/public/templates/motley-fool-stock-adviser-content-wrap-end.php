<?php
/**
 * The view for the content wrap end used in the loop
 */

?></dl><!-- .hentry -->