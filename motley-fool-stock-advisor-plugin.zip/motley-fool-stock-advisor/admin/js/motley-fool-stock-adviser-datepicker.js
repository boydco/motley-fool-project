(function( $ ) {
	'use strict';

	$(function() {

		$('.datepicker').datepicker({
			dateFormat : 'D, m/d/yy'
		});

	});

})( jQuery );