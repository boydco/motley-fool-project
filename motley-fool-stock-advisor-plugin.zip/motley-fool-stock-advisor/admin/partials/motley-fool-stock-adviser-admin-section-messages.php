<?php

/**
 * Provide a view for a section
 *
 * Enter text below to appear below the section title on the Settings page
 *
 * @link        
 * @since      1.0.0
 *
 * @package    Motley Fool Stock Adviser
 * @subpackage Motley Fool Stock Adviser/admin/partials
 */

?><p></p>